import { execFileSync } from 'node:child_process';
import { access, copyFile, lstat, mkdir, readFile } from 'node:fs/promises';
import { constants } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { verify, bundleRoot, hash } from './verify.mjs';
const manifest = await verify();
if (process.argv.length !== 3) throw new Error('Usage: node apply.mjs NEW_CLEAN_GEAR_CLONE');
const target = resolve(process.argv[2]);
const git = (args) => execFileSync('git', ['-C', target, ...args], {encoding:'utf8'});
if (git(['rev-parse','--show-toplevel']).trim() !== target || git(['rev-parse','HEAD']).trim() !== manifest.upstream.gear.commit || git(['status','--porcelain','--untracked-files=all']).trim()) throw new Error('Target must be a clean clone at the exact upstream commit');
for (const entry of manifest.overlay) {
  const destination = join(target, entry.path);
  try { await access(destination); throw new Error('Overlay destination already exists: ' + entry.path); } catch (error) { if(error.code !== 'ENOENT') throw error; }
  let parent = dirname(destination);
  while(parent !== target) { try { if ((await lstat(parent)).isSymbolicLink()) throw new Error('Symlink ancestor refused'); } catch(error) { if(error.code !== 'ENOENT') throw error; } parent = dirname(parent); }
}
const patch = join(bundleRoot, 'upgrade.patch');
git(['apply','--check',patch]);
git(['apply',patch]);
for (const entry of manifest.overlay) { const destination = join(target, entry.path); await mkdir(dirname(destination), {recursive:true}); await copyFile(join(bundleRoot,'overlay',entry.path), destination, constants.COPYFILE_EXCL); }
for (const entry of [...manifest.tracked_changes, ...manifest.overlay]) {
  if(entry.deleted) { try { await access(join(target,entry.path)); throw new Error('Expected deleted file still exists'); } catch(error) { if(error.code !== 'ENOENT') throw error; } }
  else if(hash(await readFile(join(target,entry.path))) !== entry.sha256) throw new Error('Applied source mismatch: ' + entry.path);
}
console.log(JSON.stringify({status:'applied_and_verified',tracked:manifest.tracked_changes.length,overlay:manifest.overlay.length,installsOrExperimentsRun:false}));
