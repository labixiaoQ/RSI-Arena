import { createHash } from 'node:crypto';
import { readFile, lstat } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
export const bundleRoot = fileURLToPath(new URL('./', import.meta.url));
export const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
export async function verify() {
  const manifest = JSON.parse(await readFile(join(bundleRoot, 'manifest.json'), 'utf8'));
  for (const entry of manifest.files) {
    if (!entry.path || entry.path.startsWith('/') || entry.path.includes('\\') || entry.path.split('/').some(part => part === '..' || part === '.')) throw new Error('Unsafe manifest path');
    const file = join(bundleRoot, entry.path), info = await lstat(file);
    if (!info.isFile() || info.isSymbolicLink() || hash(await readFile(file)) !== entry.sha256) throw new Error('Payload verification failed: ' + entry.path);
  }
  return manifest;
}
if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) {
  const manifest = await verify();
  console.log(JSON.stringify({verifiedFiles:manifest.files.length, upstream:manifest.upstream.gear}));
}
